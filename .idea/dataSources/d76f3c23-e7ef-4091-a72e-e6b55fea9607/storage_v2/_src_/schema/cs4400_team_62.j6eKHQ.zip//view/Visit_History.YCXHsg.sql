create view Visit_History as
  select
    `cs4400_team_62`.`Visit`.`Username` AS `Username`,
    count(0)                            AS `Logged_Visits`
  from `cs4400_team_62`.`Visit`
  group by `cs4400_team_62`.`Visit`.`Username`;

