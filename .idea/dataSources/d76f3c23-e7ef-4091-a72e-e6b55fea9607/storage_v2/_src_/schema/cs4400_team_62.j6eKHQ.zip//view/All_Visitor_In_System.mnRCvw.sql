create view All_Visitor_In_System as
  select `cs4400_team_62`.`User`.`Username` AS `Username`
  from `cs4400_team_62`.`User`
  where (`cs4400_team_62`.`User`.`Usertype` = 'ADMIN');

